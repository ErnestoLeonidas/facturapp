const crypto = require('crypto');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });

const seedData = require('../seed/seed.json');
const { withPostgresClient } = require('./postgres');

function clean(value, fallback = null) {
  if (value === undefined || value === null || value === '' || value === 'TBD') return fallback;
  return String(value).trim();
}

function slug(value, fallback = 'item') {
  const result = clean(value, fallback)
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_|_$/g, '')
    .slice(0, 50);
  return result || fallback;
}

function stableId(prefix, value) {
  const hash = crypto.createHash('sha1').update(String(value || '')).digest('hex').slice(0, 10);
  return `${prefix}_${slug(value, hash)}_${hash}`.slice(0, 90);
}

function activeFlag(value) {
  return value === false ? 0 : 1;
}

async function upsertEmpresas(client) {
  for (const empresa of seedData.empresas_emisoras || []) {
    if (!empresa.codigo || !empresa.razon_social) continue;
    await client.query(`
      INSERT INTO empresa_emisora (codigo, razon_social, rut, giro, direccion, telefono, afecto_iva, iva_pct)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      ON CONFLICT (codigo) DO UPDATE SET
        razon_social = EXCLUDED.razon_social,
        rut = COALESCE(EXCLUDED.rut, empresa_emisora.rut),
        giro = COALESCE(EXCLUDED.giro, empresa_emisora.giro),
        direccion = COALESCE(EXCLUDED.direccion, empresa_emisora.direccion),
        telefono = COALESCE(EXCLUDED.telefono, empresa_emisora.telefono),
        afecto_iva = EXCLUDED.afecto_iva,
        iva_pct = EXCLUDED.iva_pct
    `, [
      empresa.codigo,
      clean(empresa.razon_social),
      clean(empresa.rut),
      clean(empresa.giro),
      clean(empresa.direccion),
      clean(empresa.telefono),
      empresa.afecto_iva ? 1 : 0,
      empresa.afecto_iva ? 0.19 : 0
    ]);
  }
}

async function upsertCoordinadores(client) {
  const coordMap = new Map();

  for (const coordinador of seedData.coordinadores || []) {
    if (!coordinador.nombre) continue;
    const id = stableId('coor', coordinador.slack_user_id || coordinador.nombre);
    if (coordinador.slack_user_id) coordMap.set(coordinador.slack_user_id, id);
    coordMap.set(coordinador.nombre, id);

    await client.query(`
      INSERT INTO coordinador (id, nombre, email, slack_user_id, activo)
      VALUES ($1, $2, $3, $4, $5)
      ON CONFLICT (id) DO UPDATE SET
        nombre = EXCLUDED.nombre,
        email = COALESCE(EXCLUDED.email, coordinador.email),
        slack_user_id = COALESCE(EXCLUDED.slack_user_id, coordinador.slack_user_id),
        activo = EXCLUDED.activo
    `, [
      id,
      clean(coordinador.nombre),
      clean(coordinador.email),
      clean(coordinador.slack_user_id),
      activeFlag(coordinador.activo)
    ]);
  }

  return coordMap;
}

async function upsertClientes(client, coordMap) {
  for (const cliente of seedData.clientes || []) {
    if (!cliente.nombre_corto) continue;

    const clienteId = stableId('cli', cliente.nombre_corto);
    const coordinadorId = cliente.coordinador_slack ? coordMap.get(cliente.coordinador_slack) || null : null;

    await client.query(`
      INSERT INTO cliente (
        id, nombre_corto, razon_social, rut, giro, direccion, coordinador_id,
        frecuencia, dia_facturacion, requiere_hes, estado
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
      ON CONFLICT (id) DO UPDATE SET
        nombre_corto = EXCLUDED.nombre_corto,
        razon_social = COALESCE(EXCLUDED.razon_social, cliente.razon_social),
        rut = COALESCE(EXCLUDED.rut, cliente.rut),
        giro = COALESCE(EXCLUDED.giro, cliente.giro),
        direccion = COALESCE(EXCLUDED.direccion, cliente.direccion),
        coordinador_id = COALESCE(EXCLUDED.coordinador_id, cliente.coordinador_id),
        frecuencia = COALESCE(EXCLUDED.frecuencia, cliente.frecuencia),
        dia_facturacion = COALESCE(EXCLUDED.dia_facturacion, cliente.dia_facturacion),
        requiere_hes = EXCLUDED.requiere_hes,
        estado = COALESCE(EXCLUDED.estado, cliente.estado),
        updated_at = CURRENT_TIMESTAMP::text
    `, [
      clienteId,
      clean(cliente.nombre_corto),
      clean(cliente.razon_social),
      clean(cliente.rut),
      clean(cliente.giro),
      clean(cliente.direccion),
      coordinadorId,
      clean(cliente.frecuencia, 'Mensual'),
      cliente.dia_facturacion || null,
      cliente.requiere_hes ? 1 : 0,
      clean(cliente.estado, 'Activo')
    ]);

    if (coordinadorId) {
      await client.query(`
        INSERT INTO cliente_coordinador (id, cliente_id, coordinador_id, activo)
        VALUES ($1, $2, $3, 1)
        ON CONFLICT (id) DO UPDATE SET activo = 1
      `, [stableId('cc', `${clienteId}:${coordinadorId}`), clienteId, coordinadorId]);
    }

    for (const receptor of cliente.receptores || []) {
      if (!receptor.email) continue;
      await client.query(`
        INSERT INTO receptor (id, cliente_id, nombre, email, activo)
        VALUES ($1, $2, $3, $4, 1)
        ON CONFLICT (id) DO UPDATE SET
          cliente_id = EXCLUDED.cliente_id,
          nombre = EXCLUDED.nombre,
          email = EXCLUDED.email,
          activo = 1
      `, [
        stableId('recep', `${clienteId}:${receptor.email}`),
        clienteId,
        clean(receptor.nombre, receptor.email),
        clean(receptor.email)
      ]);
    }

    for (const cp of cliente.cps || []) {
      if (!cp.codigo) continue;
      await client.query(`
        INSERT INTO cp (id, codigo, nombre, area, cliente_id, activo)
        VALUES ($1, $2, $3, $4, $5, 1)
        ON CONFLICT (codigo) DO UPDATE SET
          nombre = COALESCE(EXCLUDED.nombre, cp.nombre),
          area = COALESCE(EXCLUDED.area, cp.area),
          cliente_id = COALESCE(EXCLUDED.cliente_id, cp.cliente_id),
          activo = 1
      `, [
        stableId('cp', cp.codigo),
        clean(cp.codigo),
        clean(cp.nombre),
        clean(cp.area),
        clienteId
      ]);
    }
  }
}

async function printSummary(client) {
  const tables = ['empresa_emisora', 'coordinador', 'cliente', 'receptor', 'cp'];
  for (const table of tables) {
    const result = await client.query(`SELECT COUNT(*) AS total FROM ${table}`);
    console.log(`${table}: ${result.rows[0].total}`);
  }
}

async function main() {
  if (!process.env.DATABASE_URL) {
    throw new Error('DATABASE_URL no esta configurado. Copia .env.example a .env y ajusta la clave.');
  }

  await withPostgresClient(async client => {
    await client.query('BEGIN');
    try {
      await upsertEmpresas(client);
      const coordMap = await upsertCoordinadores(client);
      await upsertClientes(client, coordMap);
      await client.query('COMMIT');
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    }

    console.log('Seed PostgreSQL completado.');
    await printSummary(client);
  });
}

main().catch(error => {
  console.error(error.message || error);
  process.exitCode = 1;
});
